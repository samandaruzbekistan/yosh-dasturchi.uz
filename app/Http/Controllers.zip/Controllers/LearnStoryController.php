<?php

namespace App\Http\Controllers;

use App\Models\LearnStory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LearnStoryController extends Controller
{

}
